# [parsol](https://telegram.me/titantims)

*new tg*


* * *

## Commands

| !help | and ...

* * *

# Install bot

```sh
cd $HOME
git clone https://github.com/mohammadrezatitan/parsol.git
cd parsol
chmod +x parsol.sh
./parsol.sh install
./parsol.sh # Enter a phone number & confirmation code.
```
### install bot(2)
```sh
cd $HOME && git clone https://github.com/mohammadrezatitan/parsol.git && cd parsol && chmod +x parsol.sh && ./parsol.sh install && ./parsol.sh
```

* * *

### Sudo And Bot
After you run the bot for first time, send it `!id`. Get your ID and stop the bot.

Open ./bot/bot.lua and add your ID to the "sudo_users" section in the following format:
```
    sudo_users = {
    267785153,
    YourID
  }
```
add your bot ID at line 4 and add your ID at line 99 in bot.lua
add your ID at line 2 in tools.lua
Then restart the bot.

### launch
```
killall screen
killall .telegram-cli
cd parsol
screen ./parsol.sh

```
* * *


# [mohammadrezajiji](https://telegram.me/mohammadrezajiji)


###  Telegram channel:

# [titantim](https://telegram.me/titantims)

### thanks to   

# [beyondtim](https://telegram.me/BeyondTeam)

# [luaerror](https://telegram.me/luaerror)

* * *
》*Please send us your stars☆ at the top of this page*

